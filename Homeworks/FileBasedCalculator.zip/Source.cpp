#include <iostream>
#include <string>
#include <fstream>

void operations(std::ofstream& out_myfile, std::string& aOperation, int& num1, int& num2) {

    int result = 0;

    //math operations
    if (aOperation.compare("add") == 0) {
        result = num1 + num2;
    }
    if (aOperation.compare("subtract") == 0) {
        result = num1 - num2;
    }
    if (aOperation.compare("divide") == 0) {
        result = num1 / num2;
    }
    if (aOperation.compare("multiply") == 0) {
        result = num1 * num2;
    }

    //prints the output
    std::string outLine = "The result of operation " + aOperation + " on " + std::to_string(num1) + " and " + std::to_string(num2) + " is below" + '\n';
    out_myfile << outLine;
    outLine = std::to_string(result) + '\n';
    out_myfile << outLine;

}

void readFile(std::string aNameIn, std::string aNameOut) {

    std::ifstream myfile(aNameIn);  //initiate streams
    std::ofstream out_myfile(aNameOut);

    //checks if streams are valid
    if (myfile.is_open() && out_myfile.is_open()) {

        std::string line;

        //scans the input file by sections of three.
        while (getline(myfile, line)) {

            std::string operation = line;
            getline(myfile, line);
            int num1 = stoi(line);
            getline(myfile, line);
            int num2 = stoi(line);

            //inputs the numbers and operation type into the operation function which will also print to the output file
            operations(out_myfile, operation, num1, num2);
        }

        //close streams
        myfile.close();
        out_myfile.close();

        std::cout << "SUCCESS!" << std::endl;
    }
    else {
        std::cout << "failed to open file" << std::endl;
    }
}

int main() {

    //file names
    std::string fileNameIn = "\input.txt";
    std::string fileNameOut = "\output.txt";

    //read file
    readFile(fileNameIn, fileNameOut);

    return 0;
}