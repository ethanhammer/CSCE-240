#include <iostream>
#include "Circle.h";
#include "Shape.h";
#define M_PI 3.14159265358979323846

Circle::Circle(double radius) {
	this->radius = radius;
	calculateArea();
	calculatePerimeter();
}

void Circle::calculateArea() {
	area = radius * radius * M_PI;
	
}

void Circle::calculatePerimeter() {
	perimeter = radius * 2 * M_PI;
}

std::string Circle::getErrorMessage()  {
	return "There was an error with the calculation for a circle";
}
