#include <iostream>
#include "Triangle.h";
#include "Shape.h";

//constructor
Triangle::Triangle(double side1, double side2, double side3) {
	this->side1 = side1;
	this->side2 = side2;
	this->side3 = side3;
	calculateArea();
	calculatePerimeter();
}

//override methods
void Triangle::calculateArea() {
	double s = (side1 + side2 + side3) / 2;
	area = sqrt(s * (s - side1) * (s - side2) * (s - side3));
}

void Triangle::calculatePerimeter() {
	perimeter = side1 + side2 + side3;
}

//static print method
std::string Triangle::getErrorMessage() {
	return "There was an error with the calculation for a Triangle";
}
