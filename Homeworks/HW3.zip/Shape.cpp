#include "Shape.h";

double Shape::getArea() {
	return area;
	}

double Shape::getPerimeter() {
	return perimeter;
	}
