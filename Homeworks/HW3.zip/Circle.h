#pragma once
#include "Shape.h";

class Circle : public Shape {

public:
	
	Circle(double radius);

	static std::string getErrorMessage();

private:

	double radius;

	 void calculateArea() override;

	 void calculatePerimeter() override;

	
	
};