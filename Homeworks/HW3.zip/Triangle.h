#pragma once
#include "Shape.h";

class Triangle : public Shape {

public:

	Triangle(double side1, double side2, double side3);

	static std::string getErrorMessage();

private:

	double side1;

	double side2;

	double side3;

	void calculateArea() override;

	void calculatePerimeter() override;



};