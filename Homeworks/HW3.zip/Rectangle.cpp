#include <iostream>
#include "Rectangle.h";
#include "Shape.h";

//constructor
Rectangle::Rectangle(double side1, double side2) {
	this->side1 = side1;
	this->side2 = side2;
	calculateArea();
	calculatePerimeter();
}

//override methods
void Rectangle::calculateArea() {
	area = side1 * side2;

}

void Rectangle::calculatePerimeter() {
	perimeter = (2 * side1) + (2 * side2);
}

//static print method
std::string Rectangle::getErrorMessage() {
	return "There was an error with the calculation for a Rectangle";
}
