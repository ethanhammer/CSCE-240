#include "Circle.h";
#include "Triangle.h";
#include "Rectangle.h";
#include <iostream>;
#include <fstream>;
#include <sstream>
#include <vector>

//creates circle object and prints to both the output file and the console
void createCircle(std::vector<std::string>& splitArray, int operation, std::ofstream& out) {
	try {
		std::string output;

		int value = std::stoi(splitArray.at(1));
		Circle circ(value);

		if (operation == 1) {
			output = "The area of the shape circle is ";
			output += std::to_string(circ.getArea());
			std::cout << output << std::endl;
			out << output << std::endl;
		}
		else {
			output = "The perimenter of the shape circle is ";
			output += std::to_string(circ.getPerimeter());
			std::cout << output << std::endl;
			out << output << std::endl;
		}
	}
	catch (const std::invalid_argument& e) {
		std::cout << Circle::getErrorMessage() << std::endl;
		out << Circle::getErrorMessage() << std::endl;
		// Handle error - not a valid number
	}
}

//creates triangle object and prints to both the output file and the console
void createTriangle(std::vector<std::string>& splitArray, int operation, std::ofstream& out) {
	try {
		std::string output;

		int value1 = std::stoi(splitArray.at(1));
		int value2 = std::stoi(splitArray.at(2));
		int value3 = std::stoi(splitArray.at(3));

		Triangle tri(value1, value2, value3);
		
		if (operation == 1) {
			//checks if the area is valid
			if (std::isnan(tri.getArea()) || tri.getArea() == 0) {
				std::cout << Triangle::getErrorMessage() << std::endl;
				out << Triangle::getErrorMessage() << std::endl;
			}
			else {
				output = "The area of the shape triangle is ";
				output += std::to_string(tri.getArea());
				std::cout << output << std::endl;
				out << output << std::endl;
			}
		}
		else {
			output = "The perimeter of the shape triangle is ";
			output += std::to_string(tri.getPerimeter());
			std::cout << output << std::endl;
			out << output << std::endl;
		}
	}
	catch (const std::invalid_argument& e) {
		std::cout << Triangle::getErrorMessage() << std::endl;
		out << Triangle::getErrorMessage() << std::endl;
		// Handle error - not a valid number
	}
}

//creates rectangle object and prints to both the output file and the console
void createRectangle(std::vector<std::string>& splitArray, int operation, std::ofstream& out) {
	try {
		std::string output;

		int value1 = std::stoi(splitArray.at(1));
		int value2 = std::stoi(splitArray.at(2));
		Rectangle rec(value1, value2);
		if (operation == 1) {
			output = "The area of the shape rectangle is ";
			output += std::to_string(rec.getArea());
			std::cout << output << std::endl;
			out << output << std::endl;
		}
		else {
			output = "The perimeter of the shape rectanlge is ";
			output += std::to_string(rec.getArea());
			std::cout << output << std::endl;
			out << output << std::endl;
		}
	}
	catch (const std::invalid_argument& e) {
		std::cout << Rectangle::getErrorMessage() << std::endl;
		out << Rectangle::getErrorMessage() << std::endl;
		// Handle error - not a valid number
	}
}

//Asks the user if they want the perimeter or the area
int getCalculationType() {
	int userInput;
	std::cout << "Press 1 to print areas or 2 to print perimeters or any other number to close" << std::endl;

	//runs until a valid input is chosen
	while (true) {
		if (std::cin >> userInput) {
			break;
		}
		else {
			std::cin.clear();
			std::cin.ignore(std::numeric_limits < std::streamsize > ::max(), '\n');
			std::cout << "wtf I said an number LMAO" << std::endl;
		}
	}
	return userInput;
}

int main() {

	std::ifstream myfile("input.txt");

	std::ofstream out_myfile("Output.txt");

	//check if files are open and return if they are not
	if (!myfile.is_open() || !out_myfile.is_open()) {
		std::cout << "Could not open desired files" << std::endl;
		return -1;
	}

	int operation = getCalculationType();
	std::string output; //variable for print
	std::string line; //current file line
	std::string currentShape; //current shape

	while (getline(myfile, line) && (operation == 1 || operation == 2)) {
		//gets shape

		try {
			std::istringstream iss(line);

			// Vector to store the split substrings
			std::vector<std::string> splitArray;

			// Split the string based on space using std::getline
			std::string substring;

			//create seperation in array.
			while (std::getline(iss, substring, ' ')) {
				splitArray.push_back(substring);
			}

			if (splitArray.at(0) == "circle" && splitArray.size() == 2) {
				createCircle(splitArray, operation, out_myfile);
			}
			else if (splitArray.at(0) == "triangle" && splitArray.size() == 4) {
				createTriangle(splitArray, operation, out_myfile);
			}
			else if (splitArray.at(0) == "rectangle" && splitArray.size() == 3) {
				createRectangle(splitArray, operation, out_myfile);
			}
			else {
				std::cout << "Invalid parameters. Ensure it is lowercase and has the proper amount of inputs" << std::endl;
				out_myfile << "Invalid parameters. Ensure it is lowercase" << std::endl;
			}

		}
		catch (const std::exception& e) {
			continue;
		}
	}

	//close shit
	myfile.close();
	out_myfile.close();
	return 0;
}