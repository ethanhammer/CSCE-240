#pragma once

#include <string>;

class Shape {

public:

	double getArea();

	double getPerimeter();

protected:

	double area;

	double perimeter;

	virtual void calculateArea() = 0;

	virtual void calculatePerimeter() = 0;

};
