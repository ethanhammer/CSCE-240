#pragma once
#include "Shape.h";

class Rectangle : public Shape {

public:

	Rectangle(double side1, double side2);

	static std::string getErrorMessage();

private:

	double side1;

	double side2;

	void calculateArea() override;

	void calculatePerimeter() override;



};