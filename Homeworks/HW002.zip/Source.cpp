#include <iostream>

#include <fstream>

#include <string>

#define M_PI 3.14159265358979323846

bool checkAfter(std::ifstream& myfile, std::string& line) {
    //checks if the amount of numbers does not exceed what is required.
    if (isdigit(myfile.peek())) {
        getline(myfile, line);
        while (isdigit(myfile.peek())) {
            getline(myfile, line);

        }
        return false;
    }
    return true;
}

bool getNum(std::ifstream& myfile, std::string& line, double& num) {
    //gets the next number from the file or return false if a letter appears when a number was expected
    if (isdigit(myfile.peek())) {
        getline(myfile, line);
        num = std::stod(line);
        return true;
    }
    else {
        return false;
    }
}
//rectangle calculations
bool findRectangle(int operation, std::ifstream& myfile, double& area, double& perimeter, std::string& line) {

    double num1;
    double num2;

    if (!getNum(myfile, line, num1)) {return false;}
    if (!getNum(myfile, line, num2)) {return false;}

    if (!checkAfter(myfile, line)) {return false;}

    if (operation == 1) {
        area = num1 * num2;
    }
    else {
        perimeter = (2 * num1) + (2 * num2);
    }
    return true;
}
//circle calculations
bool findCircle(int operation, std::ifstream& myfile, double& area, double& perimeter, std::string& line) {

    double num1;

    if (!getNum(myfile, line, num1)) {return false;}

    if (!checkAfter(myfile, line)) {return false;}

    if (operation == 1) {
        area = num1 * num1 * M_PI;
    }
    else {
        perimeter = 2 * M_PI * num1;
    }
    return true;
}
//triangle calculations
bool findTriangle(int operation, std::ifstream& myfile, double& area, double& perimeter, std::string& line) {

    double num1;
    double num2;
    double num3;

    if (!getNum(myfile, line, num1)) {return false;}
    if (!getNum(myfile, line, num2)) {return false;}
    if (!getNum(myfile, line, num3)) {return false;}

    if (!checkAfter(myfile, line)) {return false;}

    if (operation == 1) {
        double s = (num1 + num2 + num3) / 2;
        area = sqrt(s * (s - num1) * (s - num2) * (s - num3));
    }
    else {
        perimeter = num1 + num2 + num3;
    }
    return true;
}

void readFile(int operation, std::string aNameIn, std::string aNameOut) {

    std::ifstream myfile(aNameIn); //initiate streams
    std::ofstream out_myfile(aNameOut);

    //check if files are open and return if they are not
    if (!myfile.is_open() || !out_myfile.is_open()) {
        std::cout << "Could not open desired files" << std::endl;
        return;
    }

    std::string output; //variable for print
    std::string line; //current file line
    std::string currentShape; //current shape

    double area = 0; //current shape's area
    double perimeter = 0; //current shape's perimeter

    while (getline(myfile, line)) {
        //gets shape
        currentShape = line;

        //executes desired shape function
        if (line == "rectangle") {
            //checks to ensure that the shape is properly formatted
            if (!findRectangle(operation, myfile, area, perimeter, line)) {
                output = "Invalid format for rectangle \n";
                out_myfile << output;
                continue;
            }
        }
        else if (line == "circle") {
            //checks to ensure that the shape is properly formatted
            if (!findCircle(operation, myfile, area, perimeter, line)) {
                output = "Invalid format for circle \n";
                out_myfile << output;
                continue;
            }
        }
        else if (line == "triangle") {
            //checks to ensure that the shape is properly formatted
            if (!findTriangle(operation, myfile, area, perimeter, line)) {
                output = "Invalid format for triangle \n";
                out_myfile << output;
                continue;
            }
        }
        else {
            continue;
        }
        //prints to file and also checks if numbers are valid.
        if (operation == 1) {
            if (std::isnan(area) || ((currentShape == "triangle") && area == 0)) {
                output = "The area of the shape " + currentShape + " is not computable!\n";
            }
            else {
                output = "The area of the shape " + currentShape + " is " + std::to_string(area) + "\n";
            }
            out_myfile << output;
        }
        else {
            if (std::isnan(perimeter) || ((currentShape == "triangle") && area == 0)) {
                output = "The perimeter of the shape " + currentShape + " is not computable!\n";
            }
            else {
                output = "The perimeter of the shape " + currentShape + " is " + std::to_string(perimeter) + "\n";
            }
            out_myfile << output;
        }
    }

    myfile.close();
    out_myfile.close();
}

int main() {

    //file names
    std::string fileNameIn = "data/input.txt";
    std::string fileNameOut = "data/output.txt";

    //selection choice
    int userInput;
    std::cout << "Press 1 to print areas or 2 to print perimeters or any other number to close" << std::endl;

    //runs until a valid input is chosen
    while (true) {
        if (std::cin >> userInput) {
            break;
        }
        else {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits < std::streamsize > ::max(), '\n');
            std::cout << "wtf I said an number LMAO" << std::endl;
        }
    }

    //initiates reading the file
    readFile(userInput, fileNameIn, fileNameOut);

    return 0;
}