----William Ethan Hammer----

Geometric Calculator!

	The code reads an input of triangles, rectangles, and circles and outputs their areas or perimeters depending on the user's choice. The circle requires one input, the rectangle 2, and the triangle 3.

For example, if the user chooses to look at perimeters and the input.txt file is as follows:

rectangle
1
2
triangle
3
4
5
circle
1


The output file would read:

The perimeter of the shape rectangle is 6.000000
The perimeter of the shape triangle is 12.00000
The perimeter of the shape circle is 6.283185