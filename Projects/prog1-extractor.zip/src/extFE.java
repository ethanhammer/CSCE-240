import java.util.*;
	

public class extFE {

		public static void main(String[] args) {
			
			
			
			Scanner scan = new Scanner(System.in);
			
			boolean on = true;
			
			//loops until the user terminates
			while (on) {
			System.out.println("Which 10k data would you like to read? 1 for Wendy's, 2 for McDonalds, any other number to close");
			
			try {
				
			int file = scan.nextInt();
		
				if (file == 1) {
				data analyer = new data("data/Wendys.txt");
				} else if (file ==2) {
				data analyer = new data("data/McDonalds.txt");
				} else {
					on = false;
					System.out.println("bye (;");
				}
			  } catch(Exception e) {
				  System.out.println("INVALID");
				  scan.next();
			   }
			}
			scan.close();
		}

	
}
