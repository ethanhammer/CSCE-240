import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class data {


  final static String DELIM = " ";
  
  // Instance variables for each time the data is read.
  private String fileName;
  private long wordCount;
  private long charCount;
  private long lineCount;
  private long partCount;

  //Constructor takes in file name and reads the statistics.
  public data(String file) {
    fileName = file;
    
    //Assigns private variables
    wordCount = wordCount();
    charCount = charCount();
    lineCount = lineCount();
    partCount = partCount();

    writeFile();
  }

  //Prints the data to both the console and to an output file
  private void writeFile() {
	  
    FileWriter myWriter;
    
    try {
      System.out.println("Total Words: " + wordCount);
      System.out.println("Char Count: " + charCount);
      System.out.println("Line Count: " + lineCount);
      System.out.println("Part Count: " + partCount);

      myWriter = new FileWriter("data/output.txt");
      myWriter.write("Output for: " + fileName + ":\n");
      myWriter.write("Total Words: " + wordCount + "\n");
      myWriter.write("Char Count: " + charCount + "\n");
      myWriter.write("Line Count: " + lineCount + "\n");
      myWriter.write("Part Count: " + partCount + "\n");

      myWriter.close();

    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

  }
  
  //returns the line count of the desired file
  private long lineCount() {

    long lineCount = 0;
    
    Scanner input;
  //Ensures file is open
    try {
      input = new Scanner(new File(fileName), "UTF-8");
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return -1;
    }

    while (input.hasNext()) {
      lineCount++;
      input.nextLine();
    }
    
    input.close();
    return lineCount;
  }
  
  //Returns the part count
  private long partCount() {

    Scanner input;
    
    ArrayList < String > parts = new ArrayList < String > ();
  //Ensures file is open
    try {
      input = new Scanner(new File(fileName), "UTF-8");
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return -1;
    }

    while (input.hasNext()) {

      String nextLine = input.nextLine();
      String splitLine[] = nextLine.split(DELIM);
      
      //Parts are written in the files as one of these two formats.
      if (nextLine.contains("Part ") || nextLine.contains("PART ")) {
    	  //Checks the line for where the part is
        for (int k = 0; k < splitLine.length; k++) {
        	//Finds the index of the part
          if (splitLine[k].toLowerCase().equals("part")) {
        	  //Checks if it has already been written and if the length of the string line is 2.
            if (splitLine.length == 2 && !parts.contains(splitLine[k] + splitLine[k + 1])) {
              parts.add(splitLine[k] + splitLine[k + 1]);
            }
          }
        }
      }
    }
    
    input.close();
    return parts.size();

  }
  
  //Returns the word count
  private long wordCount() {

    long totalWords = 0;

    Scanner input;
  //Ensures file is open
    try {
      input = new Scanner(new File(fileName), "UTF-8");
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return -1;
    }

    while (input.hasNext()) {
    	//Word are split by spaces
      String[] line = input.nextLine().split(DELIM);
      totalWords += line.length;
    }
    
    input.close();
    return totalWords;
  }

  //Returns the character count
  private long charCount() {

    long charCount = 0;

    Scanner input;
    //Ensures file is open
    try {
      input = new Scanner(new File(fileName), "UTF-8");
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      return -1;
    }

    while (input.hasNext()) {
      charCount += input.nextLine().length();
    }
    
    input.close();
    return charCount;
  }

}